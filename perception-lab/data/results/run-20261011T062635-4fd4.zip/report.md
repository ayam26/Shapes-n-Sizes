# Run run-20261011T062635-4fd4 — EXPLORATORY high-fidelity renders: gemma4, frozen prompts rev2

- Created: 2026-10-11T06:26:35.082204Z · status: completed · provider mode: **live**
- Model: `gemma4:26b` digest `5571076f3d70` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: True · model lock frozen: True · offline guard: True · cache allowed: False
- Records: 72 (origins: live=72)

## Split: fidelity

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 36 | 36 | 0 | 0 | 36/36 (100.0%) | 36/36 (100.0%) | 36/36 (100.0%) | 0/12 (0.0%) | 12/12 (100.0%) | 12/12 (100.0%) | 1381 / 1620 (36) |
| rgb_structure_prompt | 36 | 36 | 0 | 0 | 36/36 (100.0%) | 36/36 (100.0%) | 36/36 (100.0%) | 0/12 (0.0%) | 12/12 (100.0%) | 12/12 (100.0%) | 1061 / 1304 (36) |

Paired (same RGB hash; mismatches: 0): both correct 36, baseline-only 0, variant-only 0, neither 0, unresolved 0 — of 36 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| fid-001 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1429 | live |
| fid-001 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1031 | live |
| fid-002 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1337 | live |
| fid-002 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1082 | live |
| fid-003 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1306 | live |
| fid-003 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 975 | live |
| fid-004 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1355 | live |
| fid-004 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1046 | live |
| fid-005 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1470 | live |
| fid-005 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1058 | live |
| fid-006 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1341 | live |
| fid-006 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1038 | live |
| fid-007 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1620 | live |
| fid-007 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1236 | live |
| fid-008 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1572 | live |
| fid-008 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1304 | live |
| fid-009 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1555 | live |
| fid-009 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1217 | live |
| fid-010 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1592 | live |
| fid-010 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1256 | live |
| fid-011 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1624 | live |
| fid-011 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1278 | live |
| fid-012 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1440 | live |
| fid-012 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1326 | live |
| fid-013 | fidelity | other | rgb_baseline | ok | other | correct | 1381 | live |
| fid-013 | fidelity | other | rgb_structure_prompt | ok | other | correct | 1052 | live |
| fid-014 | fidelity | other | rgb_baseline | ok | other | correct | 1339 | live |
| fid-014 | fidelity | other | rgb_structure_prompt | ok | other | correct | 1180 | live |
| fid-015 | fidelity | other | rgb_baseline | ok | other | correct | 1361 | live |
| fid-015 | fidelity | other | rgb_structure_prompt | ok | other | correct | 927 | live |
| fid-016 | fidelity | other | rgb_baseline | ok | other | correct | 1248 | live |
| fid-016 | fidelity | other | rgb_structure_prompt | ok | other | correct | 981 | live |
| fid-017 | fidelity | other | rgb_baseline | ok | other | correct | 1354 | live |
| fid-017 | fidelity | other | rgb_structure_prompt | ok | other | correct | 995 | live |
| fid-018 | fidelity | other | rgb_baseline | ok | other | correct | 1327 | live |
| fid-018 | fidelity | other | rgb_structure_prompt | ok | other | correct | 1069 | live |
| fid-019 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1448 | live |
| fid-019 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1030 | live |
| fid-020 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1318 | live |
| fid-020 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1026 | live |
| fid-021 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1529 | live |
| fid-021 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1045 | live |
| fid-022 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1302 | live |
| fid-022 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1046 | live |
| fid-023 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1433 | live |
| fid-023 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1038 | live |
| fid-024 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1303 | live |
| fid-024 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1000 | live |
| fid-025 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1483 | live |
| fid-025 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1293 | live |
| fid-026 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1499 | live |
| fid-026 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1055 | live |
| fid-027 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1496 | live |
| fid-027 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1294 | live |
| fid-028 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1513 | live |
| fid-028 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1122 | live |
| fid-029 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1464 | live |
| fid-029 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1177 | live |
| fid-030 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1424 | live |
| fid-030 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1146 | live |
| fid-031 | fidelity | other | rgb_baseline | ok | other | correct | 1342 | live |
| fid-031 | fidelity | other | rgb_structure_prompt | ok | other | correct | 1116 | live |
| fid-032 | fidelity | other | rgb_baseline | ok | other | correct | 1292 | live |
| fid-032 | fidelity | other | rgb_structure_prompt | ok | other | correct | 1097 | live |
| fid-033 | fidelity | other | rgb_baseline | ok | other | correct | 1241 | live |
| fid-033 | fidelity | other | rgb_structure_prompt | ok | other | correct | 1166 | live |
| fid-034 | fidelity | other | rgb_baseline | ok | other | correct | 1294 | live |
| fid-034 | fidelity | other | rgb_structure_prompt | ok | other | correct | 1119 | live |
| fid-035 | fidelity | other | rgb_baseline | ok | other | correct | 1299 | live |
| fid-035 | fidelity | other | rgb_structure_prompt | ok | other | correct | 1061 | live |
| fid-036 | fidelity | other | rgb_baseline | ok | other | correct | 1385 | live |
| fid-036 | fidelity | other | rgb_structure_prompt | ok | other | correct | 1003 | live |
