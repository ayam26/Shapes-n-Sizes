# Run run-20261011T060655-ef8f — EXPLORATORY cross-model: qwen3.6, development, frozen prompts rev2

- Created: 2026-10-11T06:06:55.690365Z · status: completed · provider mode: **live**
- Model: `qwen3.6:35b` digest `07d35212591f` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: True · model lock frozen: True · offline guard: True · cache allowed: False
- Records: 36 (origins: live=36)

## Split: development

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 18 | 18 | 0 | 0 | 17/18 (94.4%) | 17/18 (94.4%) | 18/18 (100.0%) | 0/6 (0.0%) | 6/6 (100.0%) | 5/6 (83.3%) | 1730 / 2248 (18) |
| rgb_structure_prompt | 18 | 18 | 0 | 0 | 12/18 (66.7%) | 12/18 (66.7%) | 18/18 (100.0%) | 3/6 (50.0%) | 6/6 (100.0%) | 3/6 (50.0%) | 2047 / 2716 (18) |

Paired (same RGB hash; mismatches: 0): both correct 12, baseline-only 5, variant-only 0, neither 1, unresolved 0 — of 18 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| core-001 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1382 | live |
| core-001 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1900 | live |
| core-002 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 2002 | live |
| core-002 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1933 | live |
| core-003 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1561 | live |
| core-003 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1702 | live |
| core-004 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1587 | live |
| core-004 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 2311 | live |
| core-005 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1600 | live |
| core-005 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1872 | live |
| core-006 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1827 | live |
| core-006 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 2047 | live |
| core-007 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 2248 | live |
| core-007 | development | flat_depiction | rgb_structure_prompt | ok | physical_vehicle | depiction_as_vehicle | 2085 | live |
| core-008 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1833 | live |
| core-008 | development | flat_depiction | rgb_structure_prompt | ok | physical_vehicle | depiction_as_vehicle | 1936 | live |
| core-009 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1775 | live |
| core-009 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2145 | live |
| core-010 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1537 | live |
| core-010 | development | flat_depiction | rgb_structure_prompt | ok | physical_vehicle | depiction_as_vehicle | 1680 | live |
| core-011 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1707 | live |
| core-011 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2331 | live |
| core-012 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1824 | live |
| core-012 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2716 | live |
| core-013 | development | other | rgb_baseline | ok | other | correct | 1799 | live |
| core-013 | development | other | rgb_structure_prompt | ok | other | correct | 2279 | live |
| core-014 | development | other | rgb_baseline | ok | other | correct | 1628 | live |
| core-014 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 2435 | live |
| core-015 | development | other | rgb_baseline | ok | other | correct | 1807 | live |
| core-015 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 2197 | live |
| core-016 | development | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1873 | live |
| core-016 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 2318 | live |
| core-017 | development | other | rgb_baseline | ok | other | correct | 1716 | live |
| core-017 | development | other | rgb_structure_prompt | ok | other | correct | 1757 | live |
| core-018 | development | other | rgb_baseline | ok | other | correct | 1730 | live |
| core-018 | development | other | rgb_structure_prompt | ok | other | correct | 1826 | live |
