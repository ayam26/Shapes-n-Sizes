# Run run-20261011T055535-5969 — HELD-OUT REPEAT (test-retest only; headline remains heldout-v1)

- Created: 2026-10-11T05:55:35.871955Z · status: completed · provider mode: **live**
- Model: `nemotron3:33b` digest `f6d8b7ff496c` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: True · model lock frozen: True · offline guard: True · cache allowed: False
- Records: 36 (origins: live=36)

## Split: heldout

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 18 | 18 | 0 | 0 | 6/18 (33.3%) | 6/18 (33.3%) | 18/18 (100.0%) | 0/6 (0.0%) | 0/6 (0.0%) | 0/6 (0.0%) | 1236 / 1308 (18) |
| rgb_structure_prompt | 18 | 18 | 0 | 0 | 8/18 (44.4%) | 8/18 (44.4%) | 18/18 (100.0%) | 0/6 (0.0%) | 2/6 (33.3%) | 0/6 (0.0%) | 1464 / 1845 (18) |

Paired (same RGB hash; mismatches: 0): both correct 6, baseline-only 0, variant-only 2, neither 10, unresolved 0 — of 18 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| core-019 | heldout | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1306 | live |
| core-019 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1215 | live |
| core-020 | heldout | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1179 | live |
| core-020 | heldout | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1296 | live |
| core-021 | heldout | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1191 | live |
| core-021 | heldout | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1305 | live |
| core-022 | heldout | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1288 | live |
| core-022 | heldout | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1376 | live |
| core-023 | heldout | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1260 | live |
| core-023 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1216 | live |
| core-024 | heldout | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1241 | live |
| core-024 | heldout | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1288 | live |
| core-025 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1214 | live |
| core-025 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1429 | live |
| core-026 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1197 | live |
| core-026 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1534 | live |
| core-027 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1236 | live |
| core-027 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1751 | live |
| core-028 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1169 | live |
| core-028 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1523 | live |
| core-029 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1291 | live |
| core-029 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1484 | live |
| core-030 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1146 | live |
| core-030 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1412 | live |
| core-031 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1245 | live |
| core-031 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1845 | live |
| core-032 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1187 | live |
| core-032 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1487 | live |
| core-033 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1308 | live |
| core-033 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1737 | live |
| core-034 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1146 | live |
| core-034 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1666 | live |
| core-035 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1251 | live |
| core-035 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1674 | live |
| core-036 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1273 | live |
| core-036 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1464 | live |
