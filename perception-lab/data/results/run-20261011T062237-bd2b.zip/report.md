# Run run-20261011T062237-bd2b — EXPLORATORY high-fidelity renders: nemotron, frozen prompts rev2

- Created: 2026-10-11T06:22:37.945415Z · status: completed · provider mode: **live**
- Model: `nemotron3:33b` digest `f6d8b7ff496c` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: True · model lock frozen: True · offline guard: True · cache allowed: False
- Records: 72 (origins: live=72)

## Split: fidelity

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 36 | 36 | 0 | 0 | 18/36 (50.0%) | 18/36 (50.0%) | 36/36 (100.0%) | 0/12 (0.0%) | 6/12 (50.0%) | 0/12 (0.0%) | 1199 / 1348 (36) |
| rgb_structure_prompt | 36 | 36 | 0 | 0 | 20/36 (55.6%) | 20/36 (55.6%) | 36/36 (100.0%) | 0/12 (0.0%) | 8/12 (66.7%) | 0/12 (0.0%) | 1339 / 1859 (36) |

Paired (same RGB hash; mismatches: 0): both correct 18, baseline-only 0, variant-only 2, neither 16, unresolved 0 — of 36 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| fid-001 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1249 | live |
| fid-001 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1250 | live |
| fid-002 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1288 | live |
| fid-002 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1204 | live |
| fid-003 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1158 | live |
| fid-003 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1339 | live |
| fid-004 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1027 | live |
| fid-004 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1314 | live |
| fid-005 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1208 | live |
| fid-005 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1257 | live |
| fid-006 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1251 | live |
| fid-006 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1219 | live |
| fid-007 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1097 | live |
| fid-007 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1343 | live |
| fid-008 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1098 | live |
| fid-008 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1390 | live |
| fid-009 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1145 | live |
| fid-009 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1318 | live |
| fid-010 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1133 | live |
| fid-010 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1596 | live |
| fid-011 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1121 | live |
| fid-011 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1334 | live |
| fid-012 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1278 | live |
| fid-012 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1229 | live |
| fid-013 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1218 | live |
| fid-013 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1661 | live |
| fid-014 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1116 | live |
| fid-014 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1207 | live |
| fid-015 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1348 | live |
| fid-015 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1626 | live |
| fid-016 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1227 | live |
| fid-016 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1406 | live |
| fid-017 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1189 | live |
| fid-017 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1903 | live |
| fid-018 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1156 | live |
| fid-018 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1467 | live |
| fid-019 | fidelity | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1428 | live |
| fid-019 | fidelity | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1280 | live |
| fid-020 | fidelity | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1277 | live |
| fid-020 | fidelity | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1297 | live |
| fid-021 | fidelity | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1274 | live |
| fid-021 | fidelity | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1859 | live |
| fid-022 | fidelity | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1216 | live |
| fid-022 | fidelity | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1339 | live |
| fid-023 | fidelity | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1259 | live |
| fid-023 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1257 | live |
| fid-024 | fidelity | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1193 | live |
| fid-024 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1314 | live |
| fid-025 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1146 | live |
| fid-025 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1251 | live |
| fid-026 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1245 | live |
| fid-026 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1255 | live |
| fid-027 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1198 | live |
| fid-027 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1613 | live |
| fid-028 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1203 | live |
| fid-028 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1454 | live |
| fid-029 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1201 | live |
| fid-029 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1326 | live |
| fid-030 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1348 | live |
| fid-030 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1414 | live |
| fid-031 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1199 | live |
| fid-031 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1837 | live |
| fid-032 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1173 | live |
| fid-032 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1569 | live |
| fid-033 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1173 | live |
| fid-033 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1807 | live |
| fid-034 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1231 | live |
| fid-034 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1448 | live |
| fid-035 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1094 | live |
| fid-035 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1713 | live |
| fid-036 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1018 | live |
| fid-036 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1437 | live |
