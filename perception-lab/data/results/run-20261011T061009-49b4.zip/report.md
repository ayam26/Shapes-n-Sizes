# Run run-20261011T061009-49b4 — EXPLORATORY cross-model: gemma4, heldout, frozen prompts rev2

- Created: 2026-10-11T06:10:09.667363Z · status: completed · provider mode: **live**
- Model: `gemma4:26b` digest `5571076f3d70` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: True · model lock frozen: True · offline guard: True · cache allowed: False
- Records: 36 (origins: live=36)

## Split: heldout

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 18 | 18 | 0 | 1 | 17/18 (94.4%) | 17/17 (100.0%) | 17/18 (94.4%) | 0/6 (0.0%) | 5/6 (83.3%) | 6/6 (100.0%) | 1329 / 1575 (18) |
| rgb_structure_prompt | 18 | 18 | 0 | 1 | 17/18 (94.4%) | 17/17 (100.0%) | 17/18 (94.4%) | 0/6 (0.0%) | 5/6 (83.3%) | 6/6 (100.0%) | 1114 / 1449 (18) |

Paired (same RGB hash; mismatches: 0): both correct 17, baseline-only 0, variant-only 0, neither 1, unresolved 0 — of 18 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| core-019 | heldout | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1522 | live |
| core-019 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1100 | live |
| core-020 | heldout | physical_vehicle | rgb_baseline | ok | uncertain | abstention | 1534 | live |
| core-020 | heldout | physical_vehicle | rgb_structure_prompt | ok | uncertain | abstention | 1279 | live |
| core-021 | heldout | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1309 | live |
| core-021 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1002 | live |
| core-022 | heldout | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1478 | live |
| core-022 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1017 | live |
| core-023 | heldout | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1383 | live |
| core-023 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1127 | live |
| core-024 | heldout | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1289 | live |
| core-024 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1043 | live |
| core-025 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1575 | live |
| core-025 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1261 | live |
| core-026 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1279 | live |
| core-026 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1272 | live |
| core-027 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1508 | live |
| core-027 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1270 | live |
| core-028 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1292 | live |
| core-028 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1230 | live |
| core-029 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1477 | live |
| core-029 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1232 | live |
| core-030 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1329 | live |
| core-030 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1449 | live |
| core-031 | heldout | other | rgb_baseline | ok | other | correct | 1349 | live |
| core-031 | heldout | other | rgb_structure_prompt | ok | other | correct | 1045 | live |
| core-032 | heldout | other | rgb_baseline | ok | other | correct | 1252 | live |
| core-032 | heldout | other | rgb_structure_prompt | ok | other | correct | 1114 | live |
| core-033 | heldout | other | rgb_baseline | ok | other | correct | 1276 | live |
| core-033 | heldout | other | rgb_structure_prompt | ok | other | correct | 1064 | live |
| core-034 | heldout | other | rgb_baseline | ok | other | correct | 1319 | live |
| core-034 | heldout | other | rgb_structure_prompt | ok | other | correct | 1154 | live |
| core-035 | heldout | other | rgb_baseline | ok | other | correct | 1329 | live |
| core-035 | heldout | other | rgb_structure_prompt | ok | other | correct | 1011 | live |
| core-036 | heldout | other | rgb_baseline | ok | other | correct | 1312 | live |
| core-036 | heldout | other | rgb_structure_prompt | ok | other | correct | 1064 | live |
