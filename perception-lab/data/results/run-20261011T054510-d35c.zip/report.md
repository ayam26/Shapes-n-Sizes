# Run run-20261011T054510-d35c — development split, prompt revision 2 (label definitions)

- Created: 2026-10-11T05:45:10.835038Z · status: completed · provider mode: **live**
- Model: `nemotron3:33b` digest `f6d8b7ff496c` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: False · model lock frozen: False · offline guard: False · cache allowed: False
- Records: 36 (origins: live=36)

## Split: development

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 18 | 18 | 0 | 0 | 12/18 (66.7%) | 12/18 (66.7%) | 18/18 (100.0%) | 0/6 (0.0%) | 6/6 (100.0%) | 0/6 (0.0%) | 1214 / 1322 (18) |
| rgb_structure_prompt | 18 | 18 | 0 | 0 | 12/18 (66.7%) | 12/18 (66.7%) | 18/18 (100.0%) | 0/6 (0.0%) | 6/6 (100.0%) | 0/6 (0.0%) | 1344 / 1597 (18) |

Paired (same RGB hash; mismatches: 0): both correct 12, baseline-only 0, variant-only 0, neither 6, unresolved 0 — of 18 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| core-001 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1214 | live |
| core-001 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1292 | live |
| core-002 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1321 | live |
| core-002 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1233 | live |
| core-003 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1151 | live |
| core-003 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1376 | live |
| core-004 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1310 | live |
| core-004 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1340 | live |
| core-005 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1273 | live |
| core-005 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1204 | live |
| core-006 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1298 | live |
| core-006 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1396 | live |
| core-007 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1192 | live |
| core-007 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1479 | live |
| core-008 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1304 | live |
| core-008 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1559 | live |
| core-009 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1134 | live |
| core-009 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1285 | live |
| core-010 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1250 | live |
| core-010 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1200 | live |
| core-011 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1166 | live |
| core-011 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1356 | live |
| core-012 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1204 | live |
| core-012 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1344 | live |
| core-013 | development | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1210 | live |
| core-013 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1344 | live |
| core-014 | development | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1198 | live |
| core-014 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1597 | live |
| core-015 | development | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1322 | live |
| core-015 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1323 | live |
| core-016 | development | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1315 | live |
| core-016 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1418 | live |
| core-017 | development | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1234 | live |
| core-017 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1484 | live |
| core-018 | development | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1170 | live |
| core-018 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1395 | live |
