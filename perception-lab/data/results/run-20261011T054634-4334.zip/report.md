# Run run-20261011T054634-4334 — HELD-OUT, frozen prompts rev2 + frozen model lock

- Created: 2026-10-11T05:46:34.392311Z · status: completed · provider mode: **live**
- Model: `nemotron3:33b` digest `f6d8b7ff496c` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: True · model lock frozen: True · offline guard: False · cache allowed: False
- Records: 36 (origins: live=36)

## Split: heldout

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 18 | 18 | 0 | 0 | 6/18 (33.3%) | 6/18 (33.3%) | 18/18 (100.0%) | 0/6 (0.0%) | 0/6 (0.0%) | 0/6 (0.0%) | 1206 / 1292 (18) |
| rgb_structure_prompt | 18 | 18 | 0 | 0 | 7/18 (38.9%) | 7/18 (38.9%) | 18/18 (100.0%) | 0/6 (0.0%) | 1/6 (16.7%) | 0/6 (0.0%) | 1453 / 1854 (18) |

Paired (same RGB hash; mismatches: 0): both correct 6, baseline-only 0, variant-only 1, neither 11, unresolved 0 — of 18 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| core-019 | heldout | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1244 | live |
| core-019 | heldout | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1274 | live |
| core-020 | heldout | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1292 | live |
| core-020 | heldout | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1294 | live |
| core-021 | heldout | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1257 | live |
| core-021 | heldout | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1387 | live |
| core-022 | heldout | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1213 | live |
| core-022 | heldout | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1298 | live |
| core-023 | heldout | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1216 | live |
| core-023 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1188 | live |
| core-024 | heldout | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1216 | live |
| core-024 | heldout | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1266 | live |
| core-025 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1196 | live |
| core-025 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1489 | live |
| core-026 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1227 | live |
| core-026 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1497 | live |
| core-027 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1189 | live |
| core-027 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1520 | live |
| core-028 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1177 | live |
| core-028 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1424 | live |
| core-029 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1254 | live |
| core-029 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1496 | live |
| core-030 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1196 | live |
| core-030 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1539 | live |
| core-031 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1206 | live |
| core-031 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1854 | live |
| core-032 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1179 | live |
| core-032 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1400 | live |
| core-033 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1183 | live |
| core-033 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1810 | live |
| core-034 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1183 | live |
| core-034 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1456 | live |
| core-035 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1149 | live |
| core-035 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1788 | live |
| core-036 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1275 | live |
| core-036 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1453 | live |
