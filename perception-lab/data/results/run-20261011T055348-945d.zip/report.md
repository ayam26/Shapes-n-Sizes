# Run run-20261011T055348-945d — OFFLINE GUARD ON: fresh held-out inference (not cached)

- Created: 2026-10-11T05:53:48.953329Z · status: completed · provider mode: **live**
- Model: `nemotron3:33b` digest `f6d8b7ff496c` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: True · model lock frozen: True · offline guard: True · cache allowed: False
- Records: 4 (origins: live=4)

## Split: heldout

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 2 | 2 | 0 | 0 | 1/2 (50.0%) | 1/2 (50.0%) | 2/2 (100.0%) | 0/1 (0.0%) | 0/1 (0.0%) | – | 1212 / 1312 (2) |
| rgb_structure_prompt | 2 | 2 | 0 | 0 | 1/2 (50.0%) | 1/2 (50.0%) | 2/2 (100.0%) | 0/1 (0.0%) | 0/1 (0.0%) | – | 1271 / 1275 (2) |

Paired (same RGB hash; mismatches: 0): both correct 1, baseline-only 0, variant-only 0, neither 1, unresolved 0 — of 2 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| core-019 | heldout | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1312 | live |
| core-019 | heldout | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1271 | live |
| core-025 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1212 | live |
| core-025 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1275 | live |
