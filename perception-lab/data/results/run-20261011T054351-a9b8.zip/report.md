# Run run-20261011T054351-a9b8 — development split, prompts not yet frozen

- Created: 2026-10-11T05:43:51.261897Z · status: completed · provider mode: **live**
- Model: `nemotron3:33b` digest `f6d8b7ff496c` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: False · model lock frozen: False · offline guard: False · cache allowed: False
- Records: 36 (origins: live=36)

## Split: development

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 18 | 18 | 0 | 2 | 9/18 (50.0%) | 9/16 (56.2%) | 16/18 (88.9%) | 1/6 (16.7%) | 6/6 (100.0%) | 0/6 (0.0%) | 1282 / 1605 (18) |
| rgb_structure_prompt | 18 | 18 | 0 | 0 | 12/18 (66.7%) | 12/18 (66.7%) | 18/18 (100.0%) | 0/6 (0.0%) | 6/6 (100.0%) | 0/6 (0.0%) | 1352 / 1676 (18) |

Paired (same RGB hash; mismatches: 0): both correct 9, baseline-only 0, variant-only 3, neither 6, unresolved 0 — of 18 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| core-001 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1387 | live |
| core-001 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1400 | live |
| core-002 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1294 | live |
| core-002 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1536 | live |
| core-003 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1130 | live |
| core-003 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1293 | live |
| core-004 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1321 | live |
| core-004 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1386 | live |
| core-005 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1492 | live |
| core-005 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1676 | live |
| core-006 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1143 | live |
| core-006 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1537 | live |
| core-007 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1126 | live |
| core-007 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1252 | live |
| core-008 | development | flat_depiction | rgb_baseline | ok | uncertain | abstention | 1309 | live |
| core-008 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1398 | live |
| core-009 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1139 | live |
| core-009 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1342 | live |
| core-010 | development | flat_depiction | rgb_baseline | ok | physical_vehicle | depiction_as_vehicle | 1282 | live |
| core-010 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1185 | live |
| core-011 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1282 | live |
| core-011 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1346 | live |
| core-012 | development | flat_depiction | rgb_baseline | ok | uncertain | abstention | 1605 | live |
| core-012 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1207 | live |
| core-013 | development | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1270 | live |
| core-013 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1352 | live |
| core-014 | development | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1394 | live |
| core-014 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1364 | live |
| core-015 | development | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1246 | live |
| core-015 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1354 | live |
| core-016 | development | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1284 | live |
| core-016 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1336 | live |
| core-017 | development | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1272 | live |
| core-017 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1528 | live |
| core-018 | development | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1377 | live |
| core-018 | development | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1345 | live |
