# Run run-20261011T060920-cc47 — EXPLORATORY cross-model: gemma4, development, frozen prompts rev2

- Created: 2026-10-11T06:09:20.385327Z · status: completed · provider mode: **live**
- Model: `gemma4:26b` digest `5571076f3d70` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: True · model lock frozen: True · offline guard: True · cache allowed: False
- Records: 36 (origins: live=36)

## Split: development

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 18 | 18 | 0 | 0 | 18/18 (100.0%) | 18/18 (100.0%) | 18/18 (100.0%) | 0/6 (0.0%) | 6/6 (100.0%) | 6/6 (100.0%) | 1363 / 1615 (18) |
| rgb_structure_prompt | 18 | 18 | 0 | 0 | 18/18 (100.0%) | 18/18 (100.0%) | 18/18 (100.0%) | 0/6 (0.0%) | 6/6 (100.0%) | 6/6 (100.0%) | 1047 / 1424 (18) |

Paired (same RGB hash; mismatches: 0): both correct 18, baseline-only 0, variant-only 0, neither 0, unresolved 0 — of 18 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| core-001 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1363 | live |
| core-001 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1018 | live |
| core-002 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1338 | live |
| core-002 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1028 | live |
| core-003 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1316 | live |
| core-003 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1123 | live |
| core-004 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1427 | live |
| core-004 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1063 | live |
| core-005 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1357 | live |
| core-005 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1011 | live |
| core-006 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1371 | live |
| core-006 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1047 | live |
| core-007 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1516 | live |
| core-007 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1359 | live |
| core-008 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1573 | live |
| core-008 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1424 | live |
| core-009 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1590 | live |
| core-009 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1267 | live |
| core-010 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1615 | live |
| core-010 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1395 | live |
| core-011 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1518 | live |
| core-011 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1210 | live |
| core-012 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1605 | live |
| core-012 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1307 | live |
| core-013 | development | other | rgb_baseline | ok | other | correct | 1368 | live |
| core-013 | development | other | rgb_structure_prompt | ok | other | correct | 894 | live |
| core-014 | development | other | rgb_baseline | ok | other | correct | 1353 | live |
| core-014 | development | other | rgb_structure_prompt | ok | other | correct | 1027 | live |
| core-015 | development | other | rgb_baseline | ok | other | correct | 1264 | live |
| core-015 | development | other | rgb_structure_prompt | ok | other | correct | 961 | live |
| core-016 | development | other | rgb_baseline | ok | other | correct | 1251 | live |
| core-016 | development | other | rgb_structure_prompt | ok | other | correct | 909 | live |
| core-017 | development | other | rgb_baseline | ok | other | correct | 1302 | live |
| core-017 | development | other | rgb_structure_prompt | ok | other | correct | 1247 | live |
| core-018 | development | other | rgb_baseline | ok | other | correct | 1350 | live |
| core-018 | development | other | rgb_structure_prompt | ok | other | correct | 966 | live |
