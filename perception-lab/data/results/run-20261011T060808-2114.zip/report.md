# Run run-20261011T060808-2114 — EXPLORATORY cross-model: qwen3.6, heldout, frozen prompts rev2

- Created: 2026-10-11T06:08:08.081018Z · status: completed · provider mode: **live**
- Model: `qwen3.6:35b` digest `07d35212591f` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: True · model lock frozen: True · offline guard: True · cache allowed: False
- Records: 36 (origins: live=36)

## Split: heldout

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 18 | 18 | 0 | 0 | 13/18 (72.2%) | 13/18 (72.2%) | 18/18 (100.0%) | 0/6 (0.0%) | 6/6 (100.0%) | 1/6 (16.7%) | 1752 / 1979 (18) |
| rgb_structure_prompt | 18 | 18 | 0 | 0 | 13/18 (72.2%) | 13/18 (72.2%) | 18/18 (100.0%) | 0/6 (0.0%) | 6/6 (100.0%) | 1/6 (16.7%) | 2061 / 2512 (18) |

Paired (same RGB hash; mismatches: 0): both correct 13, baseline-only 0, variant-only 0, neither 5, unresolved 0 — of 18 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| core-019 | heldout | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1799 | live |
| core-019 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1789 | live |
| core-020 | heldout | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1475 | live |
| core-020 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1872 | live |
| core-021 | heldout | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1702 | live |
| core-021 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 2022 | live |
| core-022 | heldout | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1592 | live |
| core-022 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1936 | live |
| core-023 | heldout | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1785 | live |
| core-023 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 2061 | live |
| core-024 | heldout | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1546 | live |
| core-024 | heldout | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 2512 | live |
| core-025 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1535 | live |
| core-025 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1900 | live |
| core-026 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1783 | live |
| core-026 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2441 | live |
| core-027 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1591 | live |
| core-027 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2119 | live |
| core-028 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1713 | live |
| core-028 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2206 | live |
| core-029 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1402 | live |
| core-029 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2087 | live |
| core-030 | heldout | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1932 | live |
| core-030 | heldout | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1930 | live |
| core-031 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1849 | live |
| core-031 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1916 | live |
| core-032 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1796 | live |
| core-032 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 2422 | live |
| core-033 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1752 | live |
| core-033 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1874 | live |
| core-034 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1756 | live |
| core-034 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 2267 | live |
| core-035 | heldout | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1784 | live |
| core-035 | heldout | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 2112 | live |
| core-036 | heldout | other | rgb_baseline | ok | other | correct | 1979 | live |
| core-036 | heldout | other | rgb_structure_prompt | ok | other | correct | 2202 | live |
