# Run run-20261011T054252-99b6 — e2e smoke (development, not frozen)

- Created: 2026-10-11T05:42:52.392159Z · status: completed · provider mode: **live**
- Model: `nemotron3:33b` digest `f6d8b7ff496c` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: False · model lock frozen: False · offline guard: False · cache allowed: False
- Records: 4 (origins: live=4)

## Split: development

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 2 | 2 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) | 2/2 (100.0%) | 0/1 (0.0%) | 1/1 (100.0%) | – | 1172 / 1384 (2) |
| rgb_structure_prompt | 2 | 2 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) | 2/2 (100.0%) | 0/1 (0.0%) | 1/1 (100.0%) | – | 1266 / 1350 (2) |

Paired (same RGB hash; mismatches: 0): both correct 2, baseline-only 0, variant-only 0, neither 0, unresolved 0 — of 2 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| core-001 | development | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1384 | live |
| core-001 | development | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1350 | live |
| core-007 | development | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1172 | live |
| core-007 | development | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1266 | live |
