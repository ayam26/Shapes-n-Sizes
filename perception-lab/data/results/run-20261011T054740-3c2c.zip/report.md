# Run run-20261011T054740-3c2c — DISCOVERY (exploratory; distance/angle/occlusion), frozen config

- Created: 2026-10-11T05:47:40.303685Z · status: completed · provider mode: **live**
- Model: `nemotron3:33b` digest `f6d8b7ff496c` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: True · model lock frozen: True · offline guard: False · cache allowed: False
- Records: 48 (origins: live=48)

## Split: discovery

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 24 | 24 | 0 | 0 | 12/24 (50.0%) | 12/24 (50.0%) | 24/24 (100.0%) | 0/8 (0.0%) | 4/8 (50.0%) | 0/8 (0.0%) | 1256 / 1354 (24) |
| rgb_structure_prompt | 24 | 24 | 0 | 0 | 12/24 (50.0%) | 12/24 (50.0%) | 24/24 (100.0%) | 0/8 (0.0%) | 4/8 (50.0%) | 0/8 (0.0%) | 1393 / 1761 (24) |

Paired (same RGB hash; mismatches: 0): both correct 12, baseline-only 0, variant-only 0, neither 12, unresolved 0 — of 24 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| disc-001 | discovery | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1328 | live |
| disc-001 | discovery | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1241 | live |
| disc-002 | discovery | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1297 | live |
| disc-002 | discovery | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1464 | live |
| disc-003 | discovery | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1189 | live |
| disc-003 | discovery | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1393 | live |
| disc-004 | discovery | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1265 | live |
| disc-004 | discovery | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1402 | live |
| disc-005 | discovery | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1256 | live |
| disc-005 | discovery | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1761 | live |
| disc-006 | discovery | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1264 | live |
| disc-006 | discovery | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1385 | live |
| disc-007 | discovery | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1306 | live |
| disc-007 | discovery | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1317 | live |
| disc-008 | discovery | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1264 | live |
| disc-008 | discovery | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1280 | live |
| disc-009 | discovery | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1291 | live |
| disc-009 | discovery | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1515 | live |
| disc-010 | discovery | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1305 | live |
| disc-010 | discovery | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1294 | live |
| disc-011 | discovery | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1197 | live |
| disc-011 | discovery | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1829 | live |
| disc-012 | discovery | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1278 | live |
| disc-012 | discovery | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1417 | live |
| disc-013 | discovery | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1253 | live |
| disc-013 | discovery | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1328 | live |
| disc-014 | discovery | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1080 | live |
| disc-014 | discovery | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1291 | live |
| disc-015 | discovery | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1185 | live |
| disc-015 | discovery | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1382 | live |
| disc-016 | discovery | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1193 | live |
| disc-016 | discovery | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1412 | live |
| disc-017 | discovery | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1140 | live |
| disc-017 | discovery | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1237 | live |
| disc-018 | discovery | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1069 | live |
| disc-018 | discovery | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1548 | live |
| disc-019 | discovery | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1239 | live |
| disc-019 | discovery | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1616 | live |
| disc-020 | discovery | physical_vehicle | rgb_baseline | ok | flat_depiction | vehicle_as_depiction | 1359 | live |
| disc-020 | discovery | physical_vehicle | rgb_structure_prompt | ok | flat_depiction | vehicle_as_depiction | 1479 | live |
| disc-021 | discovery | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1251 | live |
| disc-021 | discovery | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1315 | live |
| disc-022 | discovery | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1354 | live |
| disc-022 | discovery | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1581 | live |
| disc-023 | discovery | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1315 | live |
| disc-023 | discovery | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1441 | live |
| disc-024 | discovery | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1256 | live |
| disc-024 | discovery | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1249 | live |
