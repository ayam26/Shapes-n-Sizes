# Run run-20261011T062416-70ab — EXPLORATORY high-fidelity renders: qwen3.6, frozen prompts rev2

- Created: 2026-10-11T06:24:16.437349Z · status: completed · provider mode: **live**
- Model: `qwen3.6:35b` digest `07d35212591f` · Q4_K_M · ollama 0.23.2 · options `{"temperature": 0, "seed": 7, "num_predict": 256}` · think=False
- Prompts frozen: True · model lock frozen: True · offline guard: True · cache allowed: False
- Records: 72 (origins: live=72)

## Split: fidelity

| Method | Attempted | Valid | Op. failures | Abstain | Correct/attempted | Acc. (answered) | Coverage | False vehicle on depictions | Vehicle recall | Control correct | Latency p50/p95 ms (n) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| rgb_baseline | 36 | 36 | 0 | 0 | 33/36 (91.7%) | 33/36 (91.7%) | 36/36 (100.0%) | 0/12 (0.0%) | 12/12 (100.0%) | 9/12 (75.0%) | 1675 / 1991 (36) |
| rgb_structure_prompt | 36 | 36 | 0 | 0 | 27/36 (75.0%) | 27/36 (75.0%) | 36/36 (100.0%) | 3/12 (25.0%) | 12/12 (100.0%) | 6/12 (50.0%) | 1983 / 2534 (36) |

Paired (same RGB hash; mismatches: 0): both correct 26, baseline-only 7, variant-only 1, neither 2, unresolved 0 — of 36 pairs.

## All records

| Case | Split | Truth | Method | Status | Label | Outcome | ms | Origin |
|---|---|---|---|---|---|---|---|---|
| fid-001 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1516 | live |
| fid-001 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1962 | live |
| fid-002 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1651 | live |
| fid-002 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1752 | live |
| fid-003 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1574 | live |
| fid-003 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1833 | live |
| fid-004 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1472 | live |
| fid-004 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1751 | live |
| fid-005 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1566 | live |
| fid-005 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1796 | live |
| fid-006 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1632 | live |
| fid-006 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1918 | live |
| fid-007 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1730 | live |
| fid-007 | fidelity | flat_depiction | rgb_structure_prompt | ok | physical_vehicle | depiction_as_vehicle | 1770 | live |
| fid-008 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1765 | live |
| fid-008 | fidelity | flat_depiction | rgb_structure_prompt | ok | physical_vehicle | depiction_as_vehicle | 1607 | live |
| fid-009 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1883 | live |
| fid-009 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2164 | live |
| fid-010 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 2064 | live |
| fid-010 | fidelity | flat_depiction | rgb_structure_prompt | ok | physical_vehicle | depiction_as_vehicle | 1674 | live |
| fid-011 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1366 | live |
| fid-011 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2105 | live |
| fid-012 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1571 | live |
| fid-012 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2476 | live |
| fid-013 | fidelity | other | rgb_baseline | ok | other | correct | 1545 | live |
| fid-013 | fidelity | other | rgb_structure_prompt | ok | other | correct | 1983 | live |
| fid-014 | fidelity | other | rgb_baseline | ok | other | correct | 1888 | live |
| fid-014 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 2511 | live |
| fid-015 | fidelity | other | rgb_baseline | ok | other | correct | 1686 | live |
| fid-015 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 2091 | live |
| fid-016 | fidelity | other | rgb_baseline | ok | other | correct | 1813 | live |
| fid-016 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 2161 | live |
| fid-017 | fidelity | other | rgb_baseline | ok | other | correct | 1875 | live |
| fid-017 | fidelity | other | rgb_structure_prompt | ok | other | correct | 2226 | live |
| fid-018 | fidelity | other | rgb_baseline | ok | other | correct | 1725 | live |
| fid-018 | fidelity | other | rgb_structure_prompt | ok | other | correct | 2030 | live |
| fid-019 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1549 | live |
| fid-019 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 2534 | live |
| fid-020 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1550 | live |
| fid-020 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1582 | live |
| fid-021 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1571 | live |
| fid-021 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1940 | live |
| fid-022 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1651 | live |
| fid-022 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1819 | live |
| fid-023 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1587 | live |
| fid-023 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1913 | live |
| fid-024 | fidelity | physical_vehicle | rgb_baseline | ok | physical_vehicle | correct | 1675 | live |
| fid-024 | fidelity | physical_vehicle | rgb_structure_prompt | ok | physical_vehicle | correct | 1855 | live |
| fid-025 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1542 | live |
| fid-025 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2135 | live |
| fid-026 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1738 | live |
| fid-026 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2189 | live |
| fid-027 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1554 | live |
| fid-027 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2034 | live |
| fid-028 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1980 | live |
| fid-028 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2526 | live |
| fid-029 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1653 | live |
| fid-029 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 1836 | live |
| fid-030 | fidelity | flat_depiction | rgb_baseline | ok | flat_depiction | correct | 1894 | live |
| fid-030 | fidelity | flat_depiction | rgb_structure_prompt | ok | flat_depiction | correct | 2293 | live |
| fid-031 | fidelity | other | rgb_baseline | ok | other | correct | 1834 | live |
| fid-031 | fidelity | other | rgb_structure_prompt | ok | other | correct | 2166 | live |
| fid-032 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1991 | live |
| fid-032 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 2042 | live |
| fid-033 | fidelity | other | rgb_baseline | ok | other | correct | 1846 | live |
| fid-033 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1912 | live |
| fid-034 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1868 | live |
| fid-034 | fidelity | other | rgb_structure_prompt | ok | flat_depiction | wrong_other_label | 1930 | live |
| fid-035 | fidelity | other | rgb_baseline | ok | other | correct | 1927 | live |
| fid-035 | fidelity | other | rgb_structure_prompt | ok | other | correct | 2157 | live |
| fid-036 | fidelity | other | rgb_baseline | ok | flat_depiction | wrong_other_label | 1889 | live |
| fid-036 | fidelity | other | rgb_structure_prompt | ok | other | correct | 2552 | live |
